package com.example.teacherslist;

public class Teacher {
    String name;
    int imageId;

    public Teacher(String name) {
        this.name = name;

      //  this.imageId = imageId;
    }
}
